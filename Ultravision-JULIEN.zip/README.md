# Ultravision
A project skeleton for the [web-intermediate 2 workshop](https://github.com/Plou/workshops/tree/master/web-intermediate-2)
